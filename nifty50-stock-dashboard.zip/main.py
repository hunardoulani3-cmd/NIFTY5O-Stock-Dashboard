#NIFTY50 Stock Dashboard

import requests
import io
import yfinance as yf
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

pd.set_option("display.width", 200)
pd.set_option("display.max_columns", None)

# Fetch current NIFTY 50 constituents from NSE

def get_nifty50_symbols():
    url = "https://archives.nseindia.com/content/indices/ind_nifty50list.csv"
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

    response = requests.get(url, headers=headers, timeout=10)
    df = pd.read_csv(io.StringIO(response.text))
    symbols = df["Symbol"].tolist()[:50]

    return [f"{s}.NS" for s in symbols]


stocks = get_nifty50_symbols()
print(f"Tracking {len(stocks)} stocks: {', '.join(stocks)}")

# Fetch price data for each stock

stock_data = []

for symbol in stocks:
    stock = yf.Ticker(symbol)
    info = stock.info

    stock_data.append({
        "Symbol":          symbol,
        "Current Price":   info.get("currentPrice"),
        "Previous Close":  info.get("previousClose"),
        "Change (Rs)":     round(info.get("currentPrice") - info.get("previousClose"), 2),
        "Change (%)":      round(((info.get("currentPrice") - info.get("previousClose")) / info.get("previousClose")) * 100, 2),
        "Market Cap (Cr)": round(info.get("marketCap") / 10000000, 2),
        "Volume":          info.get("volume"),
    })
# Build and display the table

df = pd.DataFrame(stock_data)
df = df.sort_values(by="Change (%)")
df.index = range(1, len(df) + 1)
df.head(10)
print(df)
df.to_csv("nifty50_stock_data_final.csv", index=False)

# Save the table as a PNG image

def save_table_as_png(df, filename="nifty50_table_final.png", title="NIFTY 50: Live Stock Snapshot"):
    n_rows, n_cols = df.shape
    fig_height = 0.4 * n_rows + 1
    fig_width = 1.5 * n_cols

    fig, ax = plt.subplots(figsize=(fig_width, fig_height))
    ax.axis("off")

    tbl = ax.table(
        cellText=df.values,
        colLabels=df.columns,
        rowLabels=df.index,
        cellLoc="center",
        loc="center",
    )

    tbl.auto_set_font_size(False)
    tbl.set_fontsize(10)
    tbl.scale(1, 1.4)

    for (row, col), cell in tbl.get_celld().items():
        if row == 0:
            cell.set_facecolor("#404040")
            cell.set_text_props(color="white", weight="bold")
        else:
            cell.set_facecolor("#f2f2f2" )

    plt.title(title, fontsize=12, weight="bold", pad=0.5)
    plt.tight_layout()
    plt.savefig(filename, dpi=150, bbox_inches="tight")
    plt.close(fig)

save_table_as_png(df, filename="nifty50_table_final.png", title="NIFTY 50: Live Stock Snapshot")

# Plot 1-year price history

user_input = input("Enter stock symbol for graph : ").strip().upper()
symbol = user_input if user_input.endswith(".NS") else user_input + ".NS"

stock = yf.Ticker(symbol)
data = stock.history(period="1y")

plt.figure(figsize=(12, 6))
plt.plot(data.index, data["Close"], color="royalblue", linewidth=1.5)

plt.xlabel("Month")
plt.ylabel("Price (Rs.)")
plt.title(f"{symbol} - Stock Price Over the Last Year")

ax = plt.gca()
ax.xaxis.set_major_locator(mdates.MonthLocator(interval=1))
ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %Y"))
plt.xticks(rotation=60)

plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()
